#!/system/bin/sh
MODDIR=${0%/*}

# This script will be executed in late_start service mode
dbg "Sleeping until boot completes."
while [[ `getprop sys.boot_completed` -ne 1 ]]
do
       sleep 1
done

# Magisk Busybox Symlink for Apps 
ln -s /sbin/.magisk/busybox/*

write /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor performance
write /sys/devices/system/cpu/cpu1/cpufreq/scaling_governor performance
write /sys/devices/system/cpu/cpu2/cpufreq/scaling_governor performance
write /sys/devices/system/cpu/cpu3/cpufreq/scaling_governor performance
write /sys/devices/system/cpu/cpufreq/policy0/scaling_governor performance
write /sys/devices/system/cpu/cpufreq/policy4/scaling_governor performance
write /sys/devices/system/cpu/cpufreq/performance/above_hispeed_delay 0
write /sys/devices/system/cpu/cpufreq/performance/boost 1
write /sys/devices/system/cpu/cpufreq/performance/go_hispeed_load 75
write /sys/devices/system/cpu/cpufreq/performance/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpufreq/performance/align_windows 1
write /sys/kernel/gpu/gpu_governor performance
write /sys/module/adreno_idler/parameters/adreno_idler_active 0
write /sys/module/lazyplug/parameters/nr_possible_cores 8
write /sys/module/msm_performance/parameters/touchboost 1
write /dev/cpuset/foreground/boost/cpus 4-7
write /dev/cpuset/foreground/cpus 0-3,4-7
write /dev/cpuset/top-app/cpus 0-7

swapoff /dev/block/zram0
echo "1" > /sys/block/zram0/reset
echo "0" > /sys/block/zram0/disksize
echo "8" > /sys/block/zram0/max_comp_streams
chmod 644 /sys/block/zram0/disksize
echo '4294967296' > /sys/block/zram0/disksize
chmod 444 /sys/block/zram0/disksize
mkswap /dev/block/zram0 > /dev/null 2>&1
swapon /dev/block/zram0 > /dev/null 2>&1

chmod 644 /sys/module/workqueue/parameters/power_efficient
echo '0' > /sys/module/overheat_mitigation/parameters/enable
echo "200" > /sys/devices/system/cpu/cpufreq/policy0/schedutil/down_rate_limit_us
echo "3000" > /sys/devices/system/cpu/cpufreq/policy0/schedutil/up_rate_limit_us
echo "200" > /sys/devices/system/cpu/cpufreq/policy4/schedutil/down_rate_limit_us
echo "4000" > /sys/devices/system/cpu/cpufreq/policy4/schedutil/up_rate_limit_us
echo 'Y' > /sys/module/workqueue/parameters/power_efficient
echo "interactive" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor
echo "interactive" > /sys/devices/system/cpu/cpufreq/policy4/scaling_governor
echo "1113600 1401600 1612800 1747200 " > /sys/devices/system/cpu/cpufreq/policy0/scaling_available_frequencies
echo "1401600 1747200 1958400 2150400 " > /sys/devices/system/cpu/cpufreq/policy4/scaling_available_frequencies
echo '0' > /sys/devices/system/cpu/cpufreq/policy0/interactive/boostpulse
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/interactive/align_windows
echo "95" > /sys/devices/system/cpu/cpufreq/policy0/interactive/go_hispeed_load
echo '80000' > /sys/devices/system/cpu/cpufreq/policy0/interactive/timer_rate
echo '200000' > /sys/devices/system/cpu/cpufreq/policy0/interactive/timer_slack
echo '35000' > /sys/devices/system/cpu/cpufreq/policy0/interactive/min_sample_time
echo '1612800' > /sys/devices/system/cpu/cpufreq/policy0/interactive/hispeed_freq
echo '0' > /sys/devices/system/cpu/cpufreq/policy4/interactive/boostpulse
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/interactive/align_windows
echo "95" > /sys/devices/system/cpu/cpufreq/policy4/interactive/go_hispeed_load
echo '60000' > /sys/devices/system/cpu/cpufreq/policy4/interactive/timer_rate
echo '100000' > /sys/devices/system/cpu/cpufreq/policy4/interactive/timer_slack
echo '20000' > /sys/devices/system/cpu/cpufreq/policy4/interactive/min_sample_time
echo '1958400' > /sys/devices/system/cpu/cpufreq/policy4/interactive/hispeed_freq
echo "70 1401600:63 1612800:71 1747000:23" > /sys/devices/system/cpu/cpufreq/policy0/interactive/target_loads 
echo "98 1747200:23 1958400:9 2150000:85" > /sys/devices/system/cpu/cpufreq/policy4/interactive/target_loads
echo '1113600' > /sys/devices/system/cpu/cpufreq/policy0/interactive/boost
echo '1401600' > /sys/devices/system/cpu/cpufreq/policy4/interactive/boost
echo "100" > /sys/devices/system/cpu/cpufreq/policy0/schedutil/hispeed_load
echo "100" > /sys/devices/system/cpu/cpufreq/policy4/schedutil/hispeed_load
echo "100" > /sys/devices/system/cpu/cpufreq/policy0/schedutil/go_hispeed_load
echo '100' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/go_hispeed_load
echo "N" > /sys/module/msm_thermal/parameters/enabled
echo "0" > /sys/module/msm_thermal/core_control/cpus_offlined
echo "0" > /sys/module/msm_thermal/core_control/enabled
echo "0" > /sys/devices/system/cpu/cpufreq/schedutil/above_hispeed_delay 
echo "1" > /sys/module/msm_schedutil/parameters/touchboost;
echo "1" > /sys/devices/system/cpu/cpufreq/policy0/schedutil/boost
echo "1" > /sys/devices/system/cpu/cpufreq/policy4/schedutil/boost
echo "0" > /sys/devices/system/cpu/cpufreq/schedutil/above_hispeed_delay
echo "1" > /sys/devices/system/cpu/cpufreq/schedutil/boost
echo "1" > /sys/devices/system/cpu/cpufreq/schedutil/max_freq_hysteresis
echo "1" > /sys/devices/system/cpu/cpufreq/schedutil/align_windows
echo "2" > /sys/class/devfreq/5000000.qcom,kgsl-3d0/adrenoboost
echo "0" > /sys/class/kgsl/kgsl-3d0/throttling
echo "2" > /sys/class/devfreq/5900000.qcom,kgsl-3d0/subsystem/5900000.qcom,kgsl-3d0/adrenoboost
echo "0" > /sys/module/adreno_idler/parameters/adreno_idler_active 
echo "8" > /sys/module/lazyplug/parameters/nr_possible_cores 
echo '0-7' > /sys/devices/system/cpu/online;
echo '12' > /dev/stune/foreground/schedtune.boost;
echo '10' > /dev/stune/top-app/schedtune.boost;
echo '8' > /dev/stune/schedtune.boost;
echo '1' > /dev/stune/foreground/schedtune.sched_boost_no_override;
echo '1' > /dev/stune/top-app/schedtune.sched_boost_no_override;
echo '0' > /dev/stune/schedtune.colocate;
echo '0' > /dev/stune/background/schedtune.colocate;
echo '0' > /dev/stune/system-background/schedtune.colocate;
echo '0' > /dev/stune/foreground/schedtune.colocate; 
echo '1' > /dev/stune/top-app/schedtune.colocate;
echo '0' > /sys/devices/system/cpu/isolated;
echo '0' > /sys/devices/system/cpu/uevent;
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/iowait_boost_enable;
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/iowait_boost_enable;
echo '100' > /sys/module/cpu_boost/parameters/topkek_boost_ms
echo '100' > /sys/module/cpu_boost/parameters/input_boost_ms
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/pl
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/pl
echo '1501600' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/hispeed_freq
echo '1501600' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/hispeed_freq
echo '0' > /sys/module/overheat_mitigation/parameters/enable
echo '1' > /sys/devices/system/cpu/perf/enable;
echo 'boost' > /sys/devices/system/cpu/sched/sched_boost;
echo '3' > /proc/cpufreq/cpufreq_power_mode;
echo '1' > /proc/cpufreq/cpufreq_imax_enable;
echo '0' > /proc/cpufreq/cpufreq_imax_thermal_protect;

# Virtual memory tweaks
stop perfd
echo '0' > /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
echo '80' > /proc/sys/vm/overcommit_ratio
echo '150' > /proc/sys/vm/vfs_cache_pressure
echo '0' > /proc/sys/vm/extra_free_kbytes
echo '128' > /proc/sys/kernel/random/read_wakeup_threshold
echo '1024' > /proc/sys/kernel/random/write_wakeup_threshold
echo '128' > /sys/block/mmcblk0/queue/read_ahead_kb
echo '0' > /sys/block/mmcblk0/queue/iostats
echo '1' > /sys/block/mmcblk0/queue/add_random
echo '128' > /sys/block/mmcblk1/queue/read_ahead_kb
echo '0' > /sys/block/mmcblk1/queue/iostats
echo '1' > /sys/block/mmcblk1/queue/add_random
echo '4096' > /proc/sys/vm/min_free_kbytes
echo '0' > /proc/sys/vm/oom_kill_allocating_task
echo '5' > /proc/sys/vm/dirty_ratio
echo '20' > /proc/sys/vm/dirty_background_ratio
chmod 666 /sys/module/lowmemorykiller/parameters/minfree
chown root /sys/module/lowmemorykiller/parameters/minfree
echo '21816,29088,36360,43632,50904,65448' > /sys/module/lowmemorykiller/parameters/minfree
echo '1' > /proc/sys/vm/swappiness
rm /data/system/perfd/default_values
start perfd

# Virtual Memory
echo '0' > /sys/module/kernel/parameters/panic
echo '0' > /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
echo '0' > /proc/sys/vm/page-cluster
echo '8' > /sys/block/zram0/max_comp_streams 
echo '1' > /sys/module/zswap/parameters/enabled
echo '0' > /proc/sys/vm/oom_kill_allocating_task;
echo '0' > /proc/sys/vm/panic_on_oom;
echo '0' > /sys/block/mmcblk0/queue/iostats
echo '1' > /sys/block/mmcblk0/queue/add_random
echo '0' > /sys/block/mmcblk1/queue/iostats
echo '1' > /sys/block/mmcblk1/queue/add_random
echo '0' > /sys/block/mmcblk0/queue/rotational
echo '1' > /sys/block/mmcblk0/queue/rq_affinity
echo '0' > /sys/block/mmcblk0/queue/nomerges
echo '1' > /proc/sys/vm/dirty_background_ratio
echo '0' > /proc/sys/vm/page-cluster
echo 'Y' > /proc/sys/vm/swap_ratio_enable
echo "100" > /proc/sys/vm/swappiness
echo '100' > /proc/sys/vm/overcommit_ratio
echo '5' > /proc/sys/vm/dirty_background_ratio;
echo '30' > /proc/sys/vm/dirty_ratio;
echo '115' > /proc/sys/vm/vfs_cache_pressure;
echo '400' > /proc/sys/vm/dirty_writeback_centisecs;
echo '100' > /proc/sys/vm/dirty_expire_centisecs;
echo '27337' > /proc/sys/vm/extra_free_kbytes
echo '6422' > /proc/sys/vm/min_free_kbytes;
echo '0' > /proc/sys/vm/oom_kill_allocating_task;

setenforce 0
stop logd
stop thermald
echo always_on > /sys/devices/platform/13040000.mali/power_policy;
echo alweys_on > /sys/devices/platform/13040000.mali/gpuinfo;
echo alweys_support >/sys/devices/system/cpu/cpufreq/policy4/scaling_setspeed;
echo alweys_support >/sys/devices/system/cpu/cpufreq/policy6/scaling_setspeed;
echo '1' > /sys/devices/system/cpu/sched/cpu_prefer;
echo boost > /sys/devices/system/cpu/sched/sched_boost;
echo '1' > /sys/devices/system/cpu/eas/enable;
echo 'boost' > /sys/devices/system/cpu/sched/sched_boost;
echo '3' > /proc/cpufreq/cpufreq_power_mode;
echo '1' > /proc/cpufreq/cpufreq_imax_enable;
echo '0' > /proc/cpufreq/cpufreq_imax_thermal_protect;
echo '1' > /sys/devices/system/cpu/perf/enable;
chmod '0644' > /sys/devices/system/cpu/perf/enable;
sleep 0.2
echo '35' > /dev/stune/foreground/schedtune.boost;
chmod '0444' /dev/stune/foreground/schedtune.boost;
echo '1' > /proc/cpufreq/cpufreq_cci_mode;
chmod '0444' /proc/cpufreq/cpufreq_cci_mode;
echo '11000' > /sys/class/touch/switch/set_touchscreen;
echo '13060' > /sys/class/touch/switch/set_touchscreen;
echo '14005' > /sys/class/touch/switch/set_touchscreen;
echo '7035' > /sys/class/touch/switch/set_touchscreen;
echo '8002' > /sys/class/touch/switch/set_touchscreen;

# Fstrim 
echo '3' > /proc/sys/vm/drop_caches
fstrim /cache
fstrim /system
fstrim /data
done
