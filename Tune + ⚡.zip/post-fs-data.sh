#!/system/bin/sh

MODDIR=${0%/*}
write /proc/sys/vm/page-cluster 0
write /sys/block/zram0/max_comp_streams 4

setprop ro.vendor.qti.config.zram true

# Disable UFS power saving during boot

echo 0 > /sys/devices/platform/soc/1d84000.ufshc/clkgate_enable

echo 0 > /sys/devices/platform/soc/1d84000.ufshc/clkscale_enable

echo 0 > /sys/devices/platform/soc/1d84000.ufshc/hibern8_on_idle_enable

exit 0